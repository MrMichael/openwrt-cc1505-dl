# TODO List

* smaller version of structs
* remove IP info from uwifi_packet
* merge inject program
* Revive PCAP and OSX
* Parse WLAN_FRAME_CTRL_EXT according to 802.11-2016
