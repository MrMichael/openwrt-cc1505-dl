/* Just like run.c, but with all debug checks enabled. */
#define CCAN_LIST_DEBUG 1
#include <ccan/list/test/run.c>
