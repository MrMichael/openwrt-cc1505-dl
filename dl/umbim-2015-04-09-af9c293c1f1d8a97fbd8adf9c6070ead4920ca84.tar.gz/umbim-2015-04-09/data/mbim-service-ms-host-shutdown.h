/*
 * ID: 1
 * Command: Notify
 */

#define MBIM_CMD_MS_HOST_SHUTDOWN_NOTIFY	1

